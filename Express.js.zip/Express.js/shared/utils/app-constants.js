export const app_CONSTANTS = {
  ROUTES: {
    USER_ROUTES: {
      LOGIN: "/login",
      REGISTER: "/register",
      VIEWALLUSERS: "/view-all-users",
    },
  },
};
