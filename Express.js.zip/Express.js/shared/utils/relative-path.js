import path from "path";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
// console.log(__dirname)
const fullFaviconPath = path.join(__dirname, "public", "favicon.png");
console.log(fullFaviconPath);
