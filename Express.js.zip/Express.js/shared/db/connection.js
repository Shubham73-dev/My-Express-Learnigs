import sql from "mssql";
import { sqlConfig } from "./db-config.js";

export async function connection() {
  try {
    await sql.connect(sqlConfig());
    console.log("Connection Established...");
  } catch (err) {
    console.log("DB connection failed...", err);
    throw err;
  }
}

// connection(); // fires the connection function immediately after getting import --> not recommended here instead call while server initialisation in app.js
