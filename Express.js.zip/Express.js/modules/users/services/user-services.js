// Database Punching logic Files
// DB CRUD Operations
import { connection } from "../../../shared/db/connection";
import sql from "mssql";

export const userService = {
  async login(userData) {
    const inputRequest = new sql.Request();
    inputRequest
      .input("email", sql.VarChar(50), userData.email)
      .input("pwd", sql.VarChar(200), userData.password);
    try {
      const result = await inputRequest.query(
        "select * from Customers where email=@email and passwors=@pwd"
      ); // "select email, name, city from Customers where email=@email and passwors=@pwd"
      if (result && result.recordset && !!result.recordset.length) {
        return { message: "Customer Logged in successfully", result };
      } else {
        return { message: "Customer Login fails", result: result };
      }
    } catch (err) {
      throw err;
    }
  },

  async register(userData) {
    const inputRequest = new sql.Request();
    inputRequest
      .input("id", sql.Int, userData.id)
      .input("name", sql.VarChar(50), userData.name)
      .input("email", sql.VarChar(50), userData.email)
      .input("password", sql.VarChar(200), userData.password)
      .input("city", sql.VarChar(50), userData.city);
    try {
      const result = await inputRequest.query(
        "insert into Customers (customerid, name, email, password, city) values(@id, @name, @email, @password, @city)"
      ); // by adding @ we are accessing the parameters
      return { message: "Customer Registered successfully", result };
    } catch (err) {
      throw err;
    }
  },

  viewAllUsers(userData) {},

  viewOneUser(userData) {},
};
