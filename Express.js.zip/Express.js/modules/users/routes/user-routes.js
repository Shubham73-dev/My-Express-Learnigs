import express from "express";
import {
  displayUser,
  login,
  register,
  viewAllUsers,
  viewUser,
} from "../controllers/user-controller.js";
import { app_CONSTANTS } from "../../../shared/utils/app-constants.js";

export const userRoutes = express.Router();

const { LOGIN, REGISTER, VIEWALLUSERS } = app_CONSTANTS.ROUTES.USER_ROUTES;

userRoutes.post(LOGIN, login);

userRoutes.post(REGISTER, register);

userRoutes.get(VIEWALLUSERS, viewAllUsers);

userRoutes.get("/view-user/:username/:phone", viewUser);

userRoutes.get("/display-user", displayUser);
