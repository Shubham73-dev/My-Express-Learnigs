import { userService } from "../services/user-services";

export const login = async (request, response) => {
  const customerData = request.body;
  const result = await userService.login(customerData);
  response.json(result);

  // response.json({ message: "User Login" });
};

export const register = async (request, response) => {
  const customerData = request.body;
  const result = await userService.register(customerData);
  console.log("Register Data Received", customerData);
  // response.json({ message: "User register" });
  response.json(result);
};

export const viewAllUsers = (request, response) => {
  response.json({ message: "view-all-users" });
};

export const viewUser = (request, response) => {
  // for path params
  // get the path parameters
  // console.log(request.params);
  const paramsObj = request.params;
  response
    .status(200)
    .json({ "Path Params": `${paramsObj.username} ${paramsObj.phone}` });
};

export const displayUser = (request, response) => {
  // for query params
  // get the path parameters
  // console.log(request.params);
  const queryParamsObj = request.query;
  response.json({
    "query Params": `${queryParamsObj.username} ${queryParamsObj.phone}`,
  });
};
