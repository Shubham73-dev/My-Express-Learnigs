npm init
npm init -y (yes for all queries)

npm i express ---> to install express package into app

# Express is all about middlewares

* express has altogether 31 other dependencies which comes automaticllay into node modules during installation

#   "_commentDependencies": "goes to the production build",
  "dependencies": {           
    "chalk": "^5.4.1",
    "dotenv": "^17.1.0",
    "express": "^5.1.0"
  },
#  "_commentDevDependencies": "only used locally during development",
  "devDependencies": {
    "nodemon": "^3.1.10"
  }

for linux, if you want to install any packages globally, just add sudo npm i nodemon.
If not global and want to restrict only till project for development purpose, then use --save-dev syntax or simply npm i nodemon -D as an shorthand

# for running up dev build ----> npm run dev (Hot-like reload experience)
# for running up production build ----> npm start (run only once using node)

* If you as an backend developer wants to make frontend at your end in react, then in that case you can create a build of the application and place the build inside Public folder

# We create app.js file as an main file to initiate the server and run the application along with middleware integrations. Rest other logics are segregated for code structuring like creating routes and modules etc.

# In side Routes we will only specify the path while the logics will be handle in their specific controllers files and folder

# app.js --> routes.js (navigation) --> controller (req,res) --> services (DB CRUD Oprs)

docker run --cap-add SYS_PTRACE -e 'ACCEPT_EULA=1' -e 'MSSQL_SA_PASSWORD=yourStrong(!)Password' -p 1433:1433 --name azuresqledge -d mcr.microsoft.com/azure-sql-edge
