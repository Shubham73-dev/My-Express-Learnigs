import express from "express";
import chalk from "chalk";
import dotenv from "dotenv";
import favicon from "serve-favicon";
import path from "path";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { userRoutes } from "./modules/users/routes/user-routes.js";
import { connection } from "./shared/db/connection.js";

const app = express();
dotenv.config(); // reads all the variables from the env file and add it to a process
// console.log(process.argv); // this line will print the argumnets send from the package.json file from script--> start ("start": "node app.js db port uat"). You can also add multiple arguments accordingly by adding space in it
console.log(
  "DB Name",
  process.argv[2],
  "DB port number",
  process.argv[3],
  "Env",
  process.argv[4]
); // this will only console on the production build and not on dev

// Express is all about middleware --> which works as an function
// Middleware ordering matters a lot
// app.use(favicon(path.join(__dirname)))   // ---> __dirname only works with commonjs and not supported by module type
// console.log(import.meta.dirname)
const __dirname = dirname(fileURLToPath(import.meta.url));
// console.log(__dirname)
const fullFaviconPath = path.join(__dirname, "public", "favicon.png");
console.log(fullFaviconPath);

// Middlewares Section
app.use(favicon(fullFaviconPath));
app.use(express.static("public")); // app.use() attaches the middleware ---> express.static('public') is an middleware and it only works when we attach it with app.use() function. Here we are serving the static File

// dynamic sections
app.use(express.json()); // request body data reading middleware
app.use("/", userRoutes);

const promise = connection();
promise
  .then((data) => {
    console.log(chalk.greenBright.bold("DB connection Established..."));
    // Make your server up from here after sucessfull connection establishment
    const server = app.listen(process.env.PORT || 3333, (err) => {
      // initiate you application, first params is the port number
      if (err) {
        console.log(chalk.redBright.bold("application crash"), err);
      } else {
        console.log(
          chalk.greenBright.bold("application Up and Running..."),
          server.address().port
        );
      }
    });
  })
  .catch((err) => {
    console.log(chalk.red.bold("DB connection Fails", err));
  });

// const server = app.listen(process.env.PORT || 3333, (err) => {
//   // initiate you application, first params is the port number
//   if (err) {
//     console.log(chalk.redBright.bold("application crash"), err);
//   } else {
//     console.log(
//       chalk.greenBright.bold("application Up and Running..."),
//       server.address().port
//     );
//   }
// });
